package org.pattern.Designpattern;

import org.openqa.selenium.By;

public class FooterNav {

    //method to handle flights
    //when selenium executes anay method in this class- scope of selenium
    //should be in the footer only-
	
   
}
