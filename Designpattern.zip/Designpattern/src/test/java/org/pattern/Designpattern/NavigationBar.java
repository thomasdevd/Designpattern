package org.pattern.Designpattern;

public class NavigationBar {

}
