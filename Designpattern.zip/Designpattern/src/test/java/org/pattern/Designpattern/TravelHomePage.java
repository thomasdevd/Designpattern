package org.pattern.Designpattern;

public class TravelHomePage {
	
	public  NavigationBar getNavigationBar()
	{
	 return	new NavigationBar();
	}
	
	public FooterNav getFooterNav()
	{
		return new FooterNav();
	}

}
